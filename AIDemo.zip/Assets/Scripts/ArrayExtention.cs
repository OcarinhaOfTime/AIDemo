﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public static class ArrayExtention {
    public static void MapNeighborIter<T>(this T[,] map, Coord tile, UnityAction<T, int, int> onEach) {
        for(int x = tile.x - 1; x <= tile.x + 1; x++) {
            for(int y = tile.y - 1; y <= tile.y + 1; y++) {
                if(map.IsInMapRange(x, y) && (y == tile.y || x == tile.x)) {
                    onEach.Invoke(map[x, y], x, y);
                }
            }
        }
    }

    public static void MapNeighborIter(this int[,] map, Coord tile, UnityAction<int, Coord> onEach) {
        for(int x = tile.x - 1; x <= tile.x + 1; x++) {
            for(int y = tile.y - 1; y <= tile.y + 1; y++) {
                if(map.IsInMapRange(x, y) && (y == tile.y || x == tile.x)) {
                    onEach.Invoke(map[x, y], new Coord(x, y));
                }
            }
        }
    }

    public static void MapIter<T>(this T[,] map, UnityAction<T, int, int> onEach) {
        for(int x = 0; x < map.GetLength(0); x++) {
            for(int y = 0; y < map.GetLength(1); y++) {
                onEach.Invoke(map[x, y], x, y);
            }
        }
    }

    public static bool IsInMapRange<T>(this T[,] map, int x, int y) {
        return x >= 0 && x < map.GetLength(0) && y >= 0 && y < map.GetLength(1);
    }
}
